/*
var ex = 123;

function letExample(){
	//console.log(ex)//throws an exception for let...
	//let is similar to var but is based on scopes...
	let ex = "Apple123";
	console.log(ex);
}
console.log(ex);
letExample();
var array = [];
var date = new Date();
console.log(typeof(date))
console.log(typeof(array));

var varName;//var is declared but is unassigned...
varName ="Apple Test"
console.log(typeof(varName))//undefined
console.log(typeof("Test"))
console.log(typeof(123))
console.log(typeof(true));
console.log(typeof({"fruitName":"Apple","price": 45.00}));


var value = 123;
var testvalue = "123";
console.log(value == testvalue)//checks for the value not for the data types..
console.log(value === testvalue)

var data = function(test) {
 this.content = "Apple123"
 };

var obj = new data();
console.log(typeof(obj));



let arr = ["Apple","Mango","Orange"];

arr.forEach(function(e){
	console.log(e)
});//iteration as per the old syntax....

arr.forEach((e) => console.log(e));//Lambda Expressions....


function add(v1, v2){
	return v1 + v2;
}//function that returns a value



function sub(v1, v2){
	console.log(v2- v1);
}//function that does not return a value....
console.log(add(123, 234))
sub(123, 234)

var alias = function(){
	console.log("alias func")
}
alias();//the way to invoke the function...
*/

var cls = {};//object...
cls.data1 = 123;
cls.data2 ="Apple123"

//class creation in JS......
var data = function(d1, d2){
	this.data1 = d1;
	this.data2 = d2;
}


var cls = new data(123, "Apple");
var copy = new data(234, "Mango");

console.log(copy.data1)
console.log(copy.data2)
console.log(cls.data1)
console.log(cls.data2)





